#Input parameters for DCFscript
inputobject='r2_10_2.ss' #Name of pkdgrav input object
p1=5.70298 #Rotation period of the pkdgrav input object in hours
ns=1000 # Number of spheres of the pkdgrav input object
rs=3.3557050000000001e-10 # Radius of the pkdgrav input object's spheres
ftime=15.0 #Final evolution time of the simulation in Myrs
obliquity=5.00 # Initial obliquity in degrees
semimajor_a=1.0 #semimajor axis of circular orbit
thermal_i=0.0 #Input thermal inertia in SI units
fracns=0.5 # Maximum fraction of spheres allowed to move in a single event
mtol=25.0  # Tolerance of movement in sphere's radius percentage
dptol=.005 # Change in Rotation period
dDelta=5.504823e-07 # Same dDelta used in ss.par, maximum step in units of yr / 2 pi
septol=2.0*rs+.02*rs # Tolerance of sphere bouncing in terms of the radius of the pkdgrav input object's spheres

#Command-line to run the TACO and pkdgrav executables
ccp='./pkdgrav' 
ccr='./rpx'
ccs='./ss2bt'
cct='./taco'

#Output files
recordfile='simulation_record' #File to save all output from the simulation
pkdfile='pkdgrav_output' #File to save all output from the pkdgrav runs
mifile='mi_record' #File to save the moment of inertia of the objects
amspinfile='am_spin_record' #File to save the angular momentum and spin of the objects
