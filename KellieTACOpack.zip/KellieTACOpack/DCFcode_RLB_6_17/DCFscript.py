#!/usr/bin/python
import os
import subprocess
import linecache
import shlex

import DCFparams


# Default input and beggining of simulation:
DCFparams.obliquity=DCFparams.obliquity*3.14159265359/180.00 # change obliquity to radians
DCFparams.ftime=DCFparams.ftime*3.15576e+13 # change evolution time to seconds
dt=DCFparams.dDelta*24.0*365.25/(2.0*3.14159265359) # change to hours
hs=int(round(DCFparams.fracns*DCFparams.ns)) #Maximum allowed numbers of spheres to move in an event
record = file(DCFparams.recordfile, 'a')
record.write('input file= '+DCFparams.inputobject+'\n')
record.write('initial obliquity= '+str(DCFparams.obliquity)+'\n')
record.write('Change in period= '+str(DCFparams.dptol)+'\n')
record.write('Movement tolerance= '+str(DCFparams.mtol)+'\n')



##********** INPUT OBJECT
cc='cp '+DCFparams.inputobject+' inputobj.ss'
os.system(cc)


##********** RUN UNTIL IT SETTLES DOWN
pk1nsteps=int(round(DCFparams.p1/dt, -2))
pk3nsteps=3*pk1nsteps


cc=DCFparams.ccp+' -I inputobj.ss -n '+str(pk3nsteps)+' ss.par'
print cc
record.write('Run input object with initial period\n')
record.write('running pkdgrav\n')
record.write(cc+'\n')

print("Running pkdgrav")	
log = open(DCFparams.pkdfile, 'a')  # append data
c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
c.wait()	
print(" Done ")
print("  ")

if (pk3nsteps < 10000):
	ssfile='ss.0'+str(pk3nsteps)
else:
	ssfile='ss.'+str(pk3nsteps)


print("Converting .ss to .bt")
cc=DCFparams.ccs+' inputobj.ss'
os.system(cc)
cc=DCFparams.ccs+' '+ssfile
os.system(cc)

record.write('Converting .ss to .bt\n')
record.write(cc+'\n')


f = file('transformation_input', 'w')
cc='1, '+str(DCFparams.mtol)+', \'inputobj.bt\', \''+ssfile+'.bt\', \'varout\', \'inputobj_spheres\'\n'
f.write(cc)
f.close()

record.write('writing transformation_input\n')
record.write(cc+'\n')
record.write('Getting transformation\n')

print("Getting transformation")
os.system("./transformation ")
print(" Done ")
print("  ")

record.write('Did something move?\n')
f = file('checktrans', 'r')
a=f.readline()
f.close()
b=a.split(' ')[1]
cc=b+'\n'
record.write(cc)
b2=a.split(' ')[-1].strip()
cc=b2+' spheres\n'
record.write(cc)
nprot=int(b2)
record.close()
record = file(DCFparams.recordfile, 'a')



npk=pk3nsteps
##**********  ANY MOVEMENT??
##********** IF YES GO TO LOOP
nrot=2000
while nprot != nrot:
	nprot=nrot 
	record.close()
	record = file(DCFparams.recordfile, 'a')
	nstartpk=npk
	npk=npk+pk1nsteps
	

	cc1=DCFparams.ccp+' -I '+ssfile+' -nstart '+str(nstartpk)
	cc2=' -n '+str(npk)+' ss.par'
	cc=cc1+cc2
	
	
	record.write('running pkdgrav\n')
	record.write(cc+'\n')
	print 'Running pkdgrav from ',nstartpk,' to ',npk
	log = open(DCFparams.pkdfile, 'a')  #  append data
	c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
	c.wait()	
	print(" Done with pkdgrav ")
	print("  ")
	prevssfile=ssfile
	if (npk < 10000):
		ssfile='ss.0'+str(npk)
	else:
		ssfile='ss.'+str(npk)

	print("Converting .ss to .bt")

	cc=DCFparams.ccs+'  '+ssfile
	os.system(cc)
	record.write('Converting .ss to .bt\n')
	record.write(cc+'\n')

	f = file('transformation_input', 'w')
	cc='1, '+str(DCFparams.mtol)+', \'inputobj.bt\', \''+ssfile+'.bt\', \'varout\', \'inputobj_spheres\'\n'
	f.write(cc)
	f.close()
	record.write('writing transformation_input\n')
	record.write(cc)
	record.write('Getting transformation\n')


	print("Getting transformation")
	os.system("./transformation ")
	
	record.write('Did something move?\n')
	f = file('checktrans', 'r')
	a=f.readline()
	f.close()
	b=a.split(' ')[1]
	cc=b+'\n'
	record.write(cc)
	b2=a.split(' ')[-1].strip()
	cc=b2+' spheres\n'
	record.write(cc)
	nrot=int(b2)
print 'Done with while loop'
##********** IF NO CONTINUE


##********** OBJECT0 IN ORIENTATION 0
record.write('Original object is: '+ssfile+'\n')
cc='cp '+ssfile+' original.ss'
os.system(cc)
cc='cp '+ssfile+'.bt original.bt'
os.system(cc)



##Create file rpx_check to obtain object info with rpx
f = file('rpx_check', 'w')
f.write('\n')
arg='original.ss\n'
f.write(arg)
f.write('0\n')
f.write('\n')
f.write('\n')
f.write('\n')
f.write('y\n')
f.write('\n')
f.close()

##Obtain object angular momemtum and period with rpx
cc=DCFparams.ccr+' < rpx_check > rpx_output'
os.system(cc)
line = linecache.getline('rpx_output', 12)
am0=line.split(' ')[8]
line = linecache.getline('rpx_output', 11)
p1=float(line.split(' ')[8])
#define initial spin 
w0=2.0*3.14159265/(float(p1)*3600.0)
mi=float(am0)/w0

record.write('angular momemtum= '+str(am0)+'\n')
record.write('initial period= '+str(p1)+'\n')
record.write('initial spin= '+str(w0)+'\n')
record.write('Moment of inertia= '+str(mi)+'\n')
amrecord = file(DCFparams.amspinfile, 'a')
amrecord.write('original '+str(am0)+' '+str(w0)+'\n')
amrecord.close()
			
#********** GET OBJECT0'S CM, PA AND TILE
f = file('tiling_input', 'w')
cc1='1, \'original.bt\', \'x\', '
cc2='\'x\', \'x\', \'original_0\'\n'
cc=cc1+cc2
f.write(cc)
f.close()

record.close()
record = file(DCFparams.recordfile, 'a')
record.write('writing tiling_input\n')
record.write(cc)
record.write('Tiling original object\n')

print("Tiling original object")
os.system("./tiling ")
print(" Done ")
print("  ")

record.write('writing horizon_visiblepairs_input\n')
f = file('horizon_visiblepairs_input', 'w')
f.write('2\n')
f.write('original_0\n')
f.write('5\n')
f.write('6\n')
f.write('3\n')
f.write('original\n')
f.write('86\n')
f.close()
record.write('writing torques_input\n')
f = file('torques_input', 'w')
cc1='12\nsurface\n2\noriginal\n31\n'+str(DCFparams.semimajor_a)+'\n'+str(p1*3600.0)+'\n'+str(DCFparams.thermal_i)+'\n'
cc2='41\n330.0d0\noriginal_yarkovsky\noriginal_torques\n41\n335.0d0\noriginal_yarkovsky\noriginal_torques\n41\n'
cc3='340.0d0\noriginal_yarkovsky\noriginal_torques\n41\n345.0d0\noriginal_yarkovsky\noriginal_torques\n41\n'
cc4='350.0d0\noriginal_yarkovsky\noriginal_torques\n41\n355.0d0\noriginal_yarkovsky\noriginal_torques\n41\n'
cc5='0.000001d0\noriginal_yarkovsky\noriginal_torques\n'
cc=cc1+cc2+cc3+cc4+cc5
f.write(cc)
obte=5.0
for num in range(1,18):
	cc='41\n'+str(obte)+'d0\noriginal_yarkovsky\noriginal_torques\n'
	obte=obte+5.0
	f.write(cc)	
cc='41\n89.999999d0\noriginal_yarkovsky\noriginal_torques\n86\n'
f.write(cc)
f.close()

#********** GET HORIZON MAP AND TORQUES
record.write('Getting horizon_map and visible pairs\n')
print("Getting Horizon Map and Visible Pairs")
cc=DCFparams.cct+' < horizon_visiblepairs_input'
os.system(cc)
print(" Done ")
print("  ")
record.write('Asteroid structure= original\n')
record.write('Getting YORP torques\n')

print("Getting YORP torques")
cc=DCFparams.cct+' < torques_input'
os.system(cc)
print(" Done ")
print("  ")
f = file('original_torques', 'r')
f2 = file('originaltorques', 'w')
for line in f.readlines():
	y = [value for value in line.split()]
	cc=y[1]+'	'+y[2]+'\n'
	f2.write(cc)
for line in reversed(open("original_torques").readlines()[:-1]):
	y = [value for value in line.split()]
	cc1=-(float(y[1]))
	cc=str(cc1)+'	'+y[2]+'\n'
	f2.write(cc)
f.close()
f2.close()
record.write('Torques file= originaltorques\n')
mirecord = file(DCFparams.mifile, 'a')
mirecord.write('originaltorques '+str(mi)+'\n')
mirecord.close()
record.close()
record = file(DCFparams.recordfile, 'a')



#********** EVOLVE OBLIQUITY AND SPIN TO GET TARGET DW
f = file('checkincrement', 'w')
arg=' d\n'
f.write(arg)
f.close()

dp=DCFparams.dptol*p1
record.write('define target period\n')
def define_period(dp, p1):
	f = file('checkincrement', 'r')
	a=f.readline().split(' ')[1].strip()
	f.close()
	if a == 'i': 
		record.write('increasing period\n')
		p2=p1+dp
		record.write('p2= '+str(p2)+'\n')
		return p2
	else:
		record.write('decreasing period\n')
		p2=p1-dp
		record.write('p2= '+str(p2)+'\n')
		return p2
		
p2=define_period(dp, p1);
record.write('Writing evolution_input\n')
f = file('evolution_input', 'w')
arg1=str(p1)+', '+str(p2)+', '+str(mi)+', \'originaltorques\', '
arg2=str(w0)+', '+str(DCFparams.obliquity)+', 0.0, \'yorp_evolution\'\n'
f.write(arg1+arg2)
record.write(arg1+arg2)
f.close()



cc='cp checkincrement tempincrement'
os.system(cc)

record.write('Evolving spin and obliquity\n')
print("Evolving obliquity and spin")
os.system("./evolution ")
print("  ")
#********** TARGET DW EXCEEDS MAX/MIN ALLOWED SPIN RATE?
f = file('checkspin', 'r')
a=f.readline().split(' ')[1].strip()
record.write('Target  spin exceeds max or min spin rate?\n')
record.write(a+'\n')
if a == 'y': 
	f = file('mspin', 'r')
	mp=f.readline().split(' ')[3]
	p2=float(mp)
	record.write('Evolved only until max/min allowed spin rate\n')
	record.write('New period is '+mp+'\n')
#********** IF NO CONTINUE
print(" Done with evolution")
record.write('Done with evolution\n')
record.close()
record = file(DCFparams.recordfile, 'a')

#********** KICK BY DW
pk1nsteps=int(round(p2/DCFparams.dt, -2))
pk3nsteps=3*pk1nsteps
nstartpk=npk
npk=npk+pk3nsteps

kicknum=1
kick='kick'+str(kicknum)

f = file('rpx_input', 'w')
f.write('\n')
f.write('\n')
f.write('original.ss\n')
f.write('7\n')
f.write('\n')
f.write('\n')
f.write('\n')
arg='0.0 0.0 '+str(1/p2)+'\n'
f.write(arg)
f.write('0\n')
f.write('\n')
f.write('\n')
cc=kick+'.ss\n'
f.write(cc)
f.close()

cc='Creating '+kick+'.ss with spin='+str(1/p2)+'\n'
record.write(cc)
cc=DCFparams.ccr+' < rpx_input' 
os.system(cc)
print(" Done ")

tempnstartpk=nstartpk
cc=DCFparams.ccp+' -I '+kick+'.ss -nstart '+str(nstartpk)+' -n '+str(npk)+' ss.par'

record.write('running pkdgrav\n')
record.write(cc+'\n')
print("Running pkdgrav")	
log = open(DCFparams.pkdfile, 'a')  # append data
c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
c.wait()	
print(" Done ")
print("  ")



prevssfile=ssfile
if (npk < 10000):
	ssfile='ss.0'+str(npk)
else:
	ssfile='ss.'+str(npk)


#********** ANY MOVEMENT??
print("Converting .ss to .bt")
cc=DCFparams.ccs+'  '+ssfile
os.system(cc)
record.write('Converting .ss to .bt\n')
record.write(cc+'\n')


f = file('transformation_input', 'w')
cc='1, '+str(DCFparams.mtol)+', \'original.bt\', \''+ssfile+'.bt\', \'varout\', \'original_spheres\'\n'
f.write(cc)
f.close()
record.write('writing transformation_input\n')
record.write(cc)
record.write('Getting transformation\n')

print("Getting transformation")
os.system("./transformation ")
	

record.write('Did something move?\n')
f = file('checktrans', 'r')
a=f.readline()
f.close()
b=a.split(' ')[1]
cc=b+'\n'
record.write(cc)
b2=a.split(' ')[-1].strip()
cc=b2+' spheres\n'
record.write(cc)
nprot=int(b2)
record.close()
record = file(DCFparams.recordfile, 'a')
	
rpxnum=0


f = file('checkspin', 'r')
a=f.readline().split(' ')[1].strip()
if (a == 'y' and b=='y'):
	cc='cp tempincrement checkincrement'
	os.system(cc)


#********** WHILE NO MOVEMENT 
while b == 'n': 
	record.close()
	record = file(DCFparams.recordfile, 'a')
	
	cc='cp yorp_evolution temp_evolution'
	os.system(cc)
#********** EVOLVE OBLIQUITY AND SPIN TO GET TARGET DW
	
	
	#Create file rpx_check to obtain ssfile info with rpx
	f = file('rpx_check', 'w')
	f.write('\n')
	f.write('\n')
	arg=ssfile+'\n'
	f.write(arg)
	f.write('0\n')
	f.write('\n')
	f.write('\n')
	f.write('\n')
	f.write('y\n')
	f.write('\n')
	f.close()
	
	
	rpxnum=rpxnum+1
	#Obtain object angular momemtum and period with rpx
	rpxfile='rpxout'+str(rpxnum)
	cc=DCFparams.ccr+' < rpx_check > '+rpxfile
	os.system(cc)
	line = linecache.getline(rpxfile, 11)
	p1=float(line.split(' ')[8])
	##define spin 
	w0=2.0*3.14159265/(float(p1)*3600.0)
	p2=define_period(dp, p1);
	for line in open("yorp_evolution"):
   		last=line
		t0=last.split()[0]
		e0=last.split()[2]
	record.write('writing evolution_input\n')
	f = file('evolution_input', 'w')
	arg1=str(p1)+', '+str(p2)+', '+str(mi)+', \'originaltorques\', '
	arg2=str(w0)+', '+str(e0)+','+str(t0)+',  \'yorp_evolution\'\n'
	f.write(arg1+arg2)
	record.write(arg1+arg2)
	f.close()
	cc='cp checkincrement tempincrement'
	os.system(cc)
	record.write('Evolving spin and obliquity\n')
	print("Evolving obliquity and spin")
	os.system("./evolution ")
	print("  ")
	f = file('checkspin', 'r')
	a=f.readline().split(' ')[1].strip()
#********** TARGET DW EXCEEDS MAX/MIN ALLOWED SPIN RATE?
	record.write('Target  spin exceeds max or min spin rate?\n')
	record.write(a+'\n')
	if a == 'y': 
		f = file('mspin', 'r')
		mp=f.readline().split(' ')[3]
		p2=float(mp)
		record.write('Evolved only until max/min allowed spin rate\n')
		record.write('New period is '+mp+'\n')
#**********IF NO CONTINUE
	print(" Done with evolution")
	record.write('Done with evolution\n')
#********** KICK BY DW
	pk1nsteps=int(round(p2/DCFparams.dt, -2))
	pk3nsteps=3*pk1nsteps

	nstartpk=npk
	npk=npk+pk3nsteps
	
	
	kicknum=kicknum+1
	kick='kick'+str(kicknum)

	f = file('rpx_input', 'w')
	f.write('\n')
	f.write('\n')
	arg=ssfile+'\n'
	f.write(arg)
	f.write('7\n')
	f.write('\n')
	f.write('\n')
	f.write('\n')
	arg='0.0 0.0 '+str(1/p2)+'\n'
	f.write(arg)
	f.write('0\n')
	f.write('\n')
	f.write('\n')
	cc=kick+'.ss\n'
	f.write(cc)
	f.close()

	cc='Creating '+kick+'.ss with spin= '+str(1/p2)+'\n'
	record.write(cc)
	cc=DCFparams.ccr+' < rpx_input'
	os.system(cc)
	print(" Done ")
	
	tempnstartpk=nstartpk
	cc=DCFparams.ccp+' -I '+kick+'.ss -nstart '+str(nstartpk)+' -n '+str(npk)+' ss.par'
	record.write('running pkdgrav\n')
	record.write(cc+'\n')
	

	print 'Running pkdgrav from ',nstartpk,' to ',npk
	log = open(DCFparams.pkdfile, 'a')  # append data
	c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
	c.wait()	
	print(" Done with pkdgrav ")
	print("  ")
	prevssfile=ssfile
	if (npk < 10000):
		ssfile='ss.0'+str(npk)
	else:
		ssfile='ss.'+str(npk)

#********** ANY MOVEMENT??
	print("Converting .ss to .bt")
	cc=DCFparams.ccs+'  '+ssfile
	os.system(cc)
	record.write('Converting .ss to .bt\n')
	record.write(cc+'\n')
	f = file('transformation_input', 'w')
	cc='1, '+str(DCFparams.mtol)+', \'original.bt\', \''+ssfile+'.bt\', \'varout\', \'original_spheres\'\n'
	f.write(cc)
	f.close()
	record.write('writing transformation_input\n')
	record.write(cc)
	record.write('Getting transformation\n')

	print("Getting transformation")
	os.system("./transformation ")

	record.write('Did something move?\n')
	f = file('checktrans', 'r')
	a=f.readline()
	f.close()
	b=a.split(' ')[1]
	cc=b+'\n'
	record.write(cc)
	b2=a.split(' ')[-1].strip()
	cc=b2+' spheres\n'
	record.write(cc)
	nprot=int(b2)

	f = file('checkspin', 'r')
	a=f.readline().split(' ')[1].strip()
	if (a == 'y' and b=='y'):
		cc='cp tempincrement checkincrement'
		os.system(cc)
		
#********** IF THERE'S MOVEMENT RUN LONG ENOUGH TO RELAX
print 'Done with no movement  while loop'

#**********************************
#********************************
record.write('MORE THAN THE ALLOWED NUMBER OF SPHERES MOVED?\n')
nsphmov=int(b2)
if (nsphmov < hs):
	record.write('n\n')
	record.close()
	record = file(DCFparams.recordfile, 'a')
else:
#******* IF YES
	record.write('y\n')
	record.close()
	record = file(DCFparams.recordfile, 'a')
	print('MORE THAN THE ALLOWED NUMBER OF SPHERES MOVED')
	print('kicking by dw/5 instead')
	record.write('kicking by dw/5 instead\n')
	nstartpk=tempnstartpk
	#********** KICK BY DW/5 instead
	b='n'
	dptemp=abs(p2-p1)/5
	ptemp=p1
	record.write('initial period: '+str(ptemp)+'\n')
	while b == 'n':
		f = file('checkincrement', 'r')
		a=f.readline().split(' ')[1].strip()
		f.close()		
		if a == 'i': 
			ptemp=ptemp+dptemp
			record.write('increasing period to '+str(ptemp)+'\n')
		else:
			ptemp=ptemp-dptemp
			record.write('decreasing period to '+str(ptemp)+'\n')
		record.close()
		record = file(DCFparams.recordfile, 'a')

		pk1nsteps=int(round(ptemp/DCFparams.dt, -2))
		pk3nsteps=3*pk1nsteps
		npk=nstartpk+pk3nsteps
		
		kicknum=kicknum+1
		kick='kick'+str(kicknum)
		ssfile='ss.'+str(nstartpk)
		
		f = file('rpx_input', 'w')
		f.write('\n')
		f.write('\n')
		arg=ssfile+'\n'
		f.write(arg)
		f.write('7\n')
		f.write('\n')
		f.write('\n')
		f.write('\n')
		arg='0.0 0.0 '+str(1/ptemp)+'\n'
		f.write(arg)
		f.write('0\n')
		f.write('\n')
		f.write('\n')
		cc=kick+'.ss\n'
		f.write(cc)
		f.close()
	
		cc='Creating '+kick+'.ss with spin= '+str(1/ptemp)+'\n'
		record.write(cc)
		cc=DCFparams.ccr+' < rpx_input'
		os.system(cc)
		print(" Done ")
		
		tempnstartpk=nstartpk
		cc=DCFparams.ccp+' -I '+kick+'.ss -nstart '+str(nstartpk)+' -n '+str(npk)+' ss.par'
		record.write('running pkdgrav\n')
		record.write(cc+'\n')
		
	
		print 'Running pkdgrav from ',nstartpk,' to ',npk
		log = open(DCFparams.pkdfile, 'a')  # append data
		c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
		c.wait()	
		print(" Done with pkdgrav ")
		print("  ")
		prevssfile=ssfile
		if (npk < 10000):
			ssfile='ss.0'+str(npk)
		else:
			ssfile='ss.'+str(npk)
					
#	********** ANY MOVEMENT??
		print("Converting .ss to .bt")
		cc=DCFparams.ccs+'  '+ssfile
		os.system(cc)
		record.write('Converting .ss to .bt\n')
		record.write(cc+'\n')
		f = file('transformation_input', 'w')
		cc='1, '+str(DCFparams.mtol)+', \'original.bt\', \''+ssfile+'.bt\', \'varout\', \'original_spheres\'\n'
		f.write(cc)
		f.close()
		record.write('writing transformation_input\n')
		record.write(cc)
		record.write('Getting transformation\n')
	
		print("Getting transformation")
		os.system("./transformation ")
		
	
		record.write('Did something move?\n')
		f = file('checktrans', 'r')
		a=f.readline()
		f.close()
		b=a.split(' ')[1]
		cc=b+'\n'
		record.write(cc)
		b2=a.split(' ')[-1].strip()
		cc=b2+' spheres\n'
		record.write(cc)
		nprot=int(b2)
		nstartpk=npk
	p2=ptemp
	record.write('New target period '+str(ptemp)+'\n')
	cc='cp temp_evolution yorp_evolution'
	os.system(cc)
	record.write('Rewriting evolution_input\n')

	f = file('evolution_input', 'w')
	arg1=str(p1)+', '+str(p2)+', '+str(mi)+', \'originaltorques\', '
	arg2=str(w0)+', '+str(e0)+','+str(t0)+',  \'yorp_evolution\'\n'
	f.write(arg1+arg2)
	record.write(arg1+arg2)
	f.close()
	record.write('Evolving spin and obliquity to new target period instead \n')
	print("Evolving obliquity and spin")
	os.system("./evolution ")

#*****************************
#**************************
record.write('Run long enough to relax\n')

nrot=2000
while nprot != nrot:
	nprot=nrot 
	record.close()
	record = file(DCFparams.recordfile, 'a')
	nstartpk=npk
	npk=npk+pk1nsteps
	

	cc1=DCFparams.ccp+' -I '+ssfile+' -nstart '+str(nstartpk)
	cc2=' -n '+str(npk)+' ss.par'
	cc=cc1+cc2
	
	
	record.write('running pkdgrav\n')
	record.write(cc+'\n')
	print 'Running pkdgrav from ',nstartpk,' to ',npk
	log = open(DCFparams.pkdfile, 'a')  # append data
	c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
	c.wait()	
	print(" Done with pkdgrav ")
	print("  ")
	prevssfile=ssfile
	if (npk < 10000):
		ssfile='ss.0'+str(npk)
	else:
		ssfile='ss.'+str(npk)

	print("Converting .ss to .bt")
	cc=DCFparams.ccs+'  '+ssfile
	os.system(cc)
	record.write('Converting .ss to .bt\n')
	record.write(cc+'\n')

	f = file('transformation_input', 'w')
	cc='1, '+str(DCFparams.mtol)+', \'original.bt\', \''+ssfile+'.bt\', \'varout\', \'original_spheres\'\n'
	f.write(cc)
	f.close()
	record.write('writing transformation_input\n')
	record.write(cc)
	record.write('Getting transformation\n')


	print("Getting transformation")
	os.system("./transformation ")
	
	record.write('Did something move?\n')
	f = file('checktrans', 'r')
	a=f.readline()
	f.close()
	b=a.split(' ')[1]
	cc=b+'\n'
	record.write(cc)
	b2=a.split(' ')[-1].strip()
	cc=b2+' spheres\n'
	record.write(cc)
	nrot=int(b2)

print 'Done with while loop'

#********** OBJECT1 IN ORIENTATION 1
record.write('Object1 is '+ssfile+'\n')
record.close()

record = file(DCFparams.recordfile, 'a')

objnum=1
object='object'+str(objnum)

cc='cp '+ssfile+' '+object+'.ss'
os.system(cc)

cc='cp '+ssfile+'.bt '+object+'.bt'
os.system(cc)




#Create file rpx_check to obtain object info with rpx
f = file('rpx_check', 'w')
f.write('\n')
f.write('\n')
arg=object+'.ss\n'
f.write(arg)
f.write('0\n')
f.write('\n')
f.write('\n')
f.write('\n')
f.write('y\n')
f.write('\n')
f.close()



#Obtain object angular momemtum and period with rpx
rpxnum=rpxnum+1
rpxfile='rpxout'+str(rpxnum)
cc=DCFparams.ccr+' < rpx_check > '+rpxfile
os.system(cc)
line = linecache.getline(rpxfile, 12)
am0=line.split(' ')[8]
line = linecache.getline(rpxfile, 11)
p1=float(line.split(' ')[8])
##define initial spin 
w0=2.0*3.14159265/(float(p1)*3600.0)
mi=float(am0)/w0


record.write('angular momemtum= '+str(am0)+'\n')
record.write('period= '+str(p1)+'\n')
record.write('spin= '+str(w0)+'\n')
record.write('Moment of inertia= '+str(mi)+'\n')

amrecord = file(DCFparams.amspinfile, 'a')
amrecord.write('object1 '+str(am0)+' '+str(w0)+'\n')
amrecord.close()



#********** TRANSFORM OBJECT1 TO ORIENTATION 0
f = file('transformation_input', 'w')
cc='1, '+str(DCFparams.mtol)+', \'original.bt\', \''+object+'.bt\', \'varout\', \'original_spheres\'\n'
f.write(cc)
f.close()

record.write('writing transformation_input\n')
record.write(cc+'\n')
record.write('Getting transformation\n')

print("Getting transformation")
os.system("./transformation ")
print(" Done ")
print("  ")
f = file('varout', 'r')
b=f.readline()
cc='variables needed to transform '+object+' to orientation 0:\n'
record.write(cc)
record.write(b)

#********** GET CM, PA AND TILE
f = file('tiling_input', 'w')
cc1='2, \'original.bt\', \''+object+'.bt\', '
cc2='\'varout\', \''+object+'orien0\', \''+object+'_0\'\n'
cc=cc1+cc2
f.write(cc)
f.close()
record.write('writing tiling_input\n')
record.write(cc)

cc='Tiling '+object+'\n'
record.write(cc)
os.system("./tiling ")
print(" Done ")
print("  ")

#********** GET HORIZON MAP AND TORQUES
record.write('writing horizon_visiblepairs_input\n')
f = file('horizon_visiblepairs_input', 'w')
f.write('2\n')
cc=object+'_0\n'
f.write(cc)
f.write('5\n')
f.write('6\n')
f.write('3\n')
cc=object+'\n'
f.write(cc)
f.write('86\n')
f.close()

record.write('Getting horizon_map and visible pairs\n')
print("Getting Horizon Map and Visible Pairs")
cc=DCFparams.cct+' < horizon_visiblepairs_input'
os.system(cc)
print(" Done ")
print("  ")
cc='Asteroid structure= '+object+'\n'
record.write(cc)

record.write('writing torquesobj_input\n')
os.system('cp torques_input temp')
f1 = open('temp', 'r')
f2 = open('torquesobj_input', 'w')
for line in f1:
    f2.write(line.replace('original', object))
f1.close()
f2.close()
record.write('Getting YORP torques\n')
print("Getting YORP torques")
cc=DCFparams.cct+' < torquesobj_input'
os.system(cc)
print(" Done ")
print("  ")
f = file('object1_torques', 'r')
f2 = file('object1torques', 'w')
for line in f.readlines():
	y = [value for value in line.split()]
	cc=y[1]+'	'+y[2]+'\n'
	f2.write(cc)
for line in reversed(open("object1_torques").readlines()[:-1]):
	y = [value for value in line.split()]
	cc1=-(float(y[1]))
	cc=str(cc1)+'	'+y[2]+'\n'
	f2.write(cc)
f.close()
f2.close()
cc='Torques file= object1torques\n'
record.write(cc)
mirecord = file(DCFparams.mifile, 'a')
mirecord.write('object1torques '+str(mi)+'\n')
mirecord.close()



nisosph=0
prevtime=0.0
ntime=0
ncheckt=0
while (nisosph < 1) and (ntime < 1):
	record.close()
	record = file(DCFparams.recordfile, 'a')
	cc='cp yorp_evolution temp_evolution'
	os.system(cc)
#********** EVOLVE OBLIQUITY AND SPIN TO GET TARGET DW
	dp=DCFparams.dptol*p1
	p2=define_period(dp, p1);
	for line in open("yorp_evolution"):
   		last=line
		t0=last.split()[0]
		e0=last.split()[2]
	if float(t0) > DCFparams.ftime:
		ntime=5000
	if prevtime == float(t0):
		ncheckt=ncheckt+1
	else:
		ncheckt=0
	if ncheckt == 3:
		ntime=8000
	prevtime=float(t0)

	record.write('writing evolution_input\n')
#	Write evolution_input
	f = file('evolution_input', 'w')
	arg1=str(p1)+', '+str(p2)+', '+str(mi)+', \''+object+'torques\', '
	arg2=str(w0)+', '+str(e0)+','+str(t0)+',  \'yorp_evolution\'\n'
	f.write(arg1+arg2)
	record.write(arg1+arg2)
	f.close()
	cc='cp checkincrement tempincrement'
	os.system(cc)
	record.write('Evolving spin and obliquity\n')
	print("Evolving obliquity and spin")
	os.system("./evolution ")
	print("  ")
#********** TARGET DW EXCEEDS MAX/MIN ALLOWED SPIN RATE?
	f = file('checkspin', 'r')
	a=f.readline().split(' ')[1].strip()
	record.write('Target  spin exceeds max or min spin rate?\n')
	record.write(a+'\n')
	record.close()
	record = file(DCFparams.recordfile, 'a')
	if a == 'y': 
#**********IF YES dw was evolved until max/min  allowed spin rate only
		f = file('mspin', 'r')
		mp=f.readline().split(' ')[3]
		p2=float(mp)
		record.write('Evolved only until max/min allowed spin rate\n')
		record.write('New period is '+mp+'\n')
#********** IF NO CONTINUE
	print(" Done with evolution")
	record.write('Done with evolution\n')
	record.close()
	record = file(DCFparams.recordfile, 'a')

#********** KICK BY DW


	pk1nsteps=int(round(p2/DCFparams.dt, -2))
	pk3nsteps=3*pk1nsteps

	nstartpk=npk
	npk=npk+pk3nsteps
	
	kicknum=kicknum+1
	kick='kick'+str(kicknum)

	f = file('rpx_input', 'w')
	f.write('\n')
	f.write('\n')
	cc=object+'.ss\n'
	f.write(cc)
	f.write('7\n')
	f.write('\n')
	f.write('\n')
	f.write('\n')
	arg='0.0 0.0 '+str(1/p2)+'\n'
	f.write(arg)
	f.write('0\n')
	f.write('\n')
	f.write('\n')
	cc=kick+'.ss\n'
	f.write(cc)
	f.close()

	cc='Creating '+kick+'.ss with spin= '+str(1/p2)+'\n'
	record.write(cc)
	cc=DCFparams.ccr+' < rpx_input'
	os.system(cc)
	print(" Done ")

	tempnstartpk=nstartpk
	cc=DCFparams.ccp+' -I '+kick+'.ss -nstart '+str(nstartpk)+' -n '+str(npk)+' ss.par'
	record.write('running pkdgrav\n')
	record.write(cc+'\n')
	record.close()
	record = file(DCFparams.recordfile, 'a')

	print 'Running pkdgrav from ',nstartpk,' to ',npk
	log = open(DCFparams.pkdfile, 'a')  # append data
	c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
	c.wait()	
	print(" Done with pkdgrav ")
	print("  ")
	if (npk < 10000):
		ssfile='ss.0'+str(npk)
	else:
		ssfile='ss.'+str(npk)

#********** ANY MOVEMENT??
	print("Converting .ss to .bt")
	cc=DCFparams.ccs+'  '+ssfile
	os.system(cc)
	record.write('Converting .ss to .bt\n')
	record.write(cc+'\n')
	f = file('transformation_input', 'w')
	cc='2, '+str(DCFparams.mtol)+', \''+object+'orien0\', \''+ssfile+'.bt\', \'varout\', \''+object+'_spheres\'\n'
	f.write(cc)
	f.close()
	record.write('writing transformation_input\n')
	record.write(cc)
	record.write('Getting transformation\n')

	print("Getting transformation")
	os.system("./transformation ")
	

	record.write('Did something move?\n')
	f = file('checktrans', 'r')
	a=f.readline()
	f.close()
	b=a.split(' ')[1]
	cc=b+'\n'
	record.write(cc)
	b2=a.split(' ')[-1].strip()
	cc=b2+' spheres\n'
	record.write(cc)
	record.close()
	record = file(DCFparams.recordfile, 'a')
	nprot=int(b2)
	

	f = file('checkspin', 'r')
	a=f.readline().split(' ')[1].strip()
	if (a == 'y' and b=='y'):
		cc='cp tempincrement checkincrement'
		os.system(cc)
	
#********** WHILE NO MOVEMENT 
	while b == 'n': 		
		record.close()
		record = file(DCFparams.recordfile, 'a')
		
		cc='cp yorp_evolution temp_evolution'
		os.system(cc)

		f = file('rpx_check', 'w')
		f.write('\n')
		f.write('\n')
		arg=ssfile+'\n'
		f.write(arg)
		f.write('0\n')
		f.write('\n')
		f.write('\n')
		f.write('\n')
		f.write('y\n')
		f.write('\n')
		f.close()
		
		
		rpxnum=rpxnum+1
		#Obtain object angular momemtum and period with rpx
		rpxfile='rpxout'+str(rpxnum)
		cc=DCFparams.ccr+' < rpx_check > '+rpxfile
		os.system(cc)
		line = linecache.getline(rpxfile, 11)
		p1=float(line.split(' ')[8])
		##define spin 
		w0=2.0*3.14159265/(float(p1)*3600.0)
	
		p2=define_period(dp, p1);
		for line in open("yorp_evolution"):
	   		last=line
			t0=last.split()[0]
			e0=last.split()[2]
		if float(t0) > DCFparams.ftime:
			ntime=5000
		if prevtime == float(t0):
			ncheckt=ncheckt+1
		else:
			ncheckt=0
		if ncheckt == 3:
			ntime=8000
		prevtime=float(t0)
		record.write('writing evolution_input\n')
	#	Write evolution_input
		f = file('evolution_input', 'w')
		arg1=str(p1)+', '+str(p2)+', '+str(mi)+', \''+object+'torques\', '
		arg2=str(w0)+', '+str(e0)+','+str(t0)+',  \'yorp_evolution\'\n'
		f.write(arg1+arg2)
		record.write(arg1+arg2)
		f.close()
		cc='cp checkincrement tempincrement'
		os.system(cc)

		record.write('Evolving spin and obliquity\n')
		print("Evolving obliquity and spin")
		os.system("./evolution ")
		print("  ")
		f = file('checkspin', 'r')
		a=f.readline().split(' ')[1].strip()
#********** TARGET DW EXCEEDS MAX/MIN ALLOWED SPIN RATE?
		record.write('Target  spin exceeds max or min spin rate?\n')
		record.write(a+'\n')
		if a == 'y': 
#**********IF YES dw was evolved until max/min  allowed spin rate only
			f = file('mspin', 'r')
			mp=f.readline().split(' ')[3]
			p2=float(mp)
			record.write('Evolved only until max/min allowed spin rate\n')
			record.write('New period is '+mp+'\n')

#**********IF NO CONTINUE
		print(" Done with evolution")
		record.write('Done with evolution\n')
#********** KICK BY DW
		pk1nsteps=int(round(p2/DCFparams.dt, -2))
		pk3nsteps=3*pk1nsteps
	
		nstartpk=npk
		npk=npk+pk3nsteps
		
		kicknum=kicknum+1
		kick='kick'+str(kicknum)
	
		f = file('rpx_input', 'w')
		f.write('\n')
		f.write('\n')
		arg=ssfile+'\n'
		f.write(arg)
		f.write('7\n')
		f.write('\n')
		f.write('\n')
		f.write('\n')
		arg='0.0 0.0 '+str(1/p2)+'\n'
		f.write(arg)
		f.write('0\n')
		f.write('\n')
		f.write('\n')
		cc=kick+'.ss\n'
		f.write(cc)
		f.close()
	
		cc='Creating '+kick+'.ss with spin= '+str(1/p2)+'\n'
		record.write(cc)
		cc=DCFparams.ccr+' < rpx_input'
		os.system(cc)
		print(" Done ")
		
		tempnstartpk=nstartpk
		
		cc=DCFparams.ccp+' -I '+kick+'.ss -nstart '+str(nstartpk)+' -n '+str(npk)+' ss.par'
		record.write('running pkdgrav\n')
		record.write(cc+'\n')
		
	
		print 'Running pkdgrav from ',nstartpk,' to ',npk
		log = open(DCFparams.pkdfile, 'a')  # append data
		c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
		c.wait()	
		print(" Done with pkdgrav ")
		print("  ")
		prevssfile=ssfile
		if (npk < 10000):
			ssfile='ss.0'+str(npk)
		else:
			ssfile='ss.'+str(npk)
	
	#********** ANY MOVEMENT??
		print("Converting .ss to .bt")
		cc=DCFparams.ccs+'  '+ssfile
		os.system(cc)
		record.write('Converting .ss to .bt\n')
		record.write(cc+'\n')
		f = file('transformation_input', 'w')
		cc='2, '+str(DCFparams.mtol)+', \''+object+'orien0\', \''+ssfile+'.bt\', \'varout\', \''+object+'_spheres\'\n'
		f.write(cc)
		f.close()
		record.write('writing transformation_input\n')
		record.write(cc)
		record.write('Getting transformation\n')
	
		print("Getting transformation")
		os.system("./transformation ")
	
	
		record.write('Did something move?\n')
		f = file('checktrans', 'r')
		a=f.readline()
		f.close()
		b=a.split(' ')[1]
		cc=b+'\n'
		record.write(cc)
		b2=a.split(' ')[-1].strip()
		cc=b2+' spheres\n'
		record.write(cc)
		nprot=int(b2)
		
	
		f = file('checkspin', 'r')
		a=f.readline().split(' ')[1].strip()
		if (a == 'y' and b=='y'):
			cc='cp tempincrement checkincrement'
			os.system(cc)
	
	#********** IF THERE'S MOVEMENT 
	print 'Done with NO MOVEMENT while loop'
	
	
	
	#******** MORE THAN ALLOWED NUMBER OF SPHERES MOVED?
	record.write('MORE THAN THE ALLOWED NUMBER OF SPHERES MOVED?\n')
	nsphmov=int(b2)
	if (nsphmov < hs):
		record.write('n\n')
		record.close()
		record = file(DCFparams.recordfile, 'a')

	else:
#******* IF YES
		record.write('y\n')
		record.close()
		record = file(DCFparams.recordfile, 'a')
		print('MORE THAN THE ALLOWED NUMBER OF SPHERES MOVED')
		print('kicking by dw/5 instead')
		record.write('kicking by dw/5 instead\n')
		nstartpk=tempnstartpk
		#********** KICK BY DW/5 instead
		b='n'
		dptemp=abs(p2-p1)/5
		ptemp=p1
		record.write('initial period: '+str(ptemp)+'\n')
		while b == 'n':
			f = file('checkincrement', 'r')
			a=f.readline().split(' ')[1].strip()
			f.close()		
			if a == 'i': 
				ptemp=ptemp+dptemp
				record.write('increasing period to '+str(ptemp)+'\n')
			else:
				ptemp=ptemp-dptemp
				record.write('decreasing period to '+str(ptemp)+'\n')
			record.close()
			record = file(DCFparams.recordfile, 'a')
	
			pk1nsteps=int(round(ptemp/DCFparams.dt, -2))
			pk3nsteps=3*pk1nsteps
			npk=nstartpk+pk3nsteps
			
			kicknum=kicknum+1
			kick='kick'+str(kicknum)
			ssfile='ss.'+str(nstartpk)
			
			f = file('rpx_input', 'w')
			f.write('\n')
			f.write('\n')
			arg=ssfile+'\n'
			f.write(arg)
			f.write('7\n')
			f.write('\n')
			f.write('\n')
			f.write('\n')
			arg='0.0 0.0 '+str(1/ptemp)+'\n'
			f.write(arg)
			f.write('0\n')
			f.write('\n')
			f.write('\n')
			cc=kick+'.ss\n'
			f.write(cc)
			f.close()
		
			cc='Creating '+kick+'.ss with spin= '+str(1/ptemp)+'\n'
			record.write(cc)
			cc=DCFparams.ccr+' < rpx_input'
			os.system(cc)
			print(" Done ")
			
			tempnstartpk=nstartpk
			cc=DCFparams.ccp+' -I '+kick+'.ss -nstart '+str(nstartpk)+' -n '+str(npk)+' ss.par'
			record.write('running pkdgrav\n')
			record.write(cc+'\n')
			
		
			print 'Running pkdgrav from ',nstartpk,' to ',npk
			log = open(DCFparams.pkdfile, 'a')  # append data
			c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
			c.wait()	
			print(" Done with pkdgrav ")
			print("  ")
			prevssfile=ssfile
			if (npk < 10000):
				ssfile='ss.0'+str(npk)
			else:
				ssfile='ss.'+str(npk)
		
		#********** ANY MOVEMENT??
			print("Converting .ss to .bt")
			cc=DCFparams.ccs+'  '+ssfile
			os.system(cc)
			record.write('Converting .ss to .bt\n')
			record.write(cc+'\n')
			f = file('transformation_input', 'w')
			cc='2, '+str(DCFparams.mtol)+', \''+object+'orien0\', \''+ssfile+'.bt\', \'varout\', \''+object+'_spheres\'\n'
			f.write(cc)
			f.close()
			record.write('writing transformation_input\n')
			record.write(cc)
			record.write('Getting transformation\n')
		
			print("Getting transformation")
			os.system("./transformation ")
			
		
			record.write('Did something move?\n')
			f = file('checktrans', 'r')
			a=f.readline()
			f.close()
			b=a.split(' ')[1]
			cc=b+'\n'
			record.write(cc)
			b2=a.split(' ')[-1].strip()
			cc=b2+' spheres\n'
			record.write(cc)
			nprot=int(b2)
			nstartpk=npk
		p2=ptemp
		record.write('New target period '+str(ptemp)+'\n')
		cc='cp temp_evolution yorp_evolution'
		os.system(cc)
		record.write('Rewriting evolution_input\n')
		f = file('evolution_input', 'w')
		arg1=str(p1)+', '+str(p2)+', '+str(mi)+', \''+object+'torques\', '
		arg2=str(w0)+', '+str(e0)+','+str(t0)+',  \'yorp_evolution\'\n'
		f.write(arg1+arg2)
		record.write(arg1+arg2)
		f.close()
		record.write('Evolving spin and obliquity to new target period instead \n')
		print("Evolving obliquity and spin")
		os.system("./evolution ")

#**********************************************
		#************************************************
		
	record.write('Run long enough to relax\n')
	record.close()
	record = file(DCFparams.recordfile, 'a')
	nrot=2000

	while nprot != nrot:
		nprot=nrot
		nstartpk=npk
		npk=npk+pk1nsteps
		
	
		cc1=DCFparams.ccp+' -I '+ssfile+' -nstart '+str(nstartpk)
		cc2=' -n '+str(npk)+' ss.par'
		cc=cc1+cc2
		
		
		record.write('running pkdgrav\n')
		record.write(cc+'\n')
		print 'Running pkdgrav from ',nstartpk,' to ',npk
		log = open(DCFparams.pkdfile, 'a')  # append data
		c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
		c.wait()	
		print(" Done with pkdgrav ")
		print("  ")
		prevssfile=ssfile
		if (npk < 10000):
			ssfile='ss.0'+str(npk)
		else:
			ssfile='ss.'+str(npk)
	
		print("Converting .ss to .bt")
		cc=DCFparams.ccs+'  '+ssfile
		os.system(cc)
		record.write('Converting .ss to .bt\n')
		record.write(cc+'\n')
	
		f = file('transformation_input', 'w')
		cc='2, '+str(DCFparams.mtol)+', \''+object+'orien0\', \''+ssfile+'.bt\', \'varout\', \''+object+'_spheres\'\n'
		f.write(cc)
		f.close()
		record.write('writing transformation_input\n')
		record.write(cc)
		record.write('Getting transformation\n')
	
	
		print("Getting transformation")
		os.system("./transformation ")
		

		record.write('Did something move?\n')
		f = file('checktrans', 'r')
		a=f.readline()
		f.close()
		b=a.split(' ')[1]
		cc=b+'\n'
		record.write(cc)
		b2=a.split(' ')[-1].strip()
		cc=b2+' spheres\n'
		record.write(cc)
		nrot=int(b2)
	
	#***********************************
	record.write('MORE THAN THE ALLOWED NUMBER OF SPHERES MOVED?\n')
	nsphmov=int(b2)
	if (nsphmov < hs):
		record.write('n\n')
		record.close()
		record = file(DCFparams.recordfile, 'a')
	else:
#******* IF YES
		record.write('y\n')
		record.close()
		record = file(DCFparams.recordfile, 'a')
		print('MORE THAN THE ALLOWED NUMBER OF SPHERES MOVED')
		print('kicking by dw/5 instead')
		record.write('kicking by dw/5 instead\n')
		nstartpk=tempnstartpk
		#********** KICK BY DW/5 instead
		b='n'
		dptemp=abs(p2-p1)/5
		ptemp=p1
		record.write('initial period: '+str(ptemp)+'\n')
		while b == 'n':
			f = file('checkincrement', 'r')
			a=f.readline().split(' ')[1].strip()
			f.close()		
			if a == 'i': 
				ptemp=ptemp+dptemp
				record.write('increasing period to '+str(ptemp)+'\n')
			else:
				ptemp=ptemp-dptemp
				record.write('decreasing period to '+str(ptemp)+'\n')
			record.close()
			record = file(DCFparams.recordfile, 'a')

			pk1nsteps=int(round(ptemp/DCFparams.dt, -2))
			pk3nsteps=3*pk1nsteps
			npk=nstartpk+pk3nsteps
			
			kicknum=kicknum+1
			kick='kick'+str(kicknum)
			ssfile='ss.'+str(nstartpk)
			
			f = file('rpx_input', 'w')
			f.write('\n')
			f.write('\n')
			arg=ssfile+'\n'
			f.write(arg)
			f.write('7\n')
			f.write('\n')
			f.write('\n')
			f.write('\n')
			arg='0.0 0.0 '+str(1/ptemp)+'\n'
			f.write(arg)
			f.write('0\n')
			f.write('\n')
			f.write('\n')
			cc=kick+'.ss\n'
			f.write(cc)
			f.close()
		
			cc='Creating '+kick+'.ss with spin= '+str(1/ptemp)+'\n'
			record.write(cc)
			cc=DCFparams.ccr+' < rpx_input'
			os.system(cc)
			print(" Done ")
		
			cc=DCFparams.ccp+' -I '+kick+'.ss -nstart '+str(nstartpk)+' -n '+str(npk)+' ss.par'
			record.write('running pkdgrav\n')
			record.write(cc+'\n')
			
		
			print 'Running pkdgrav from ',nstartpk,' to ',npk
			log = open(DCFparams.pkdfile, 'a')  # append data
			c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
			c.wait()	
			print(" Done with pkdgrav ")
			print("  ")
			prevssfile=ssfile
			if (npk < 10000):
				ssfile='ss.0'+str(npk)
			else:
				ssfile='ss.'+str(npk)
		
		#********** ANY MOVEMENT??
			print("Converting .ss to .bt")
			cc=DCFparams.ccs+'  '+ssfile
			os.system(cc)
			record.write('Converting .ss to .bt\n')
			record.write(cc+'\n')
			f = file('transformation_input', 'w')
			cc='2, '+str(DCFparams.mtol)+', \''+object+'orien0\', \''+ssfile+'.bt\', \'varout\', \''+object+'_spheres\'\n'
			f.write(cc)
			f.close()
			record.write('writing transformation_input\n')
			record.write(cc)
			record.write('Getting transformation\n')
		
			print("Getting transformation")
			os.system("./transformation ")
			
		
			record.write('Did something move?\n')
			f = file('checktrans', 'r')
			a=f.readline()
			f.close()
			b=a.split(' ')[1]
			cc=b+'\n'
			record.write(cc)
			b2=a.split(' ')[-1].strip()
			cc=b2+' spheres\n'
			record.write(cc)
			nprot=int(b2)
			nstartpk=npk
		p2=ptemp
		record.write('New target period '+str(ptemp)+'\n')
		cc='cp temp_evolution yorp_evolution'
		os.system(cc)
		record.write('Rewriting evolution_input\n')
		f = file('evolution_input', 'w')
		arg1=str(p1)+', '+str(p2)+', '+str(mi)+', \''+object+'torques\', '
		arg2=str(w0)+', '+str(e0)+','+str(t0)+',  \'yorp_evolution\'\n'
		f.write(arg1+arg2)
		record.write(arg1+arg2)
		f.close()
		record.write('Evolving spin and obliquity to new target period instead \n')
		print("Evolving obliquity and spin")
		os.system("./evolution ")


		record.write('Run long enough to relax\n')
		record.close()
		record = file(DCFparams.recordfile, 'a')
		nrot=2000
	#	while b == 'y': 
		while nprot != nrot:
			nprot=nrot
			nstartpk=npk
			npk=npk+pk1nsteps
			
		
			cc1=DCFparams.ccp+' -I '+ssfile+' -nstart '+str(nstartpk)
			cc2=' -n '+str(npk)+' ss.par'
			cc=cc1+cc2
			
			
			record.write('running pkdgrav\n')
			record.write(cc+'\n')
			print 'Running pkdgrav from ',nstartpk,' to ',npk
			log = open(DCFparams.pkdfile, 'a')  # append data
			c = subprocess.Popen([cc], stdout=log, stderr=log, shell=True)
			c.wait()	
			print(" Done with pkdgrav ")
			print("  ")
			prevssfile=ssfile
			if (npk < 10000):
				ssfile='ss.0'+str(npk)
			else:
				ssfile='ss.'+str(npk)
		
			print("Converting .ss to .bt")
			cc=DCFparams.ccs+'  '+ssfile
			os.system(cc)
			record.write('Converting .ss to .bt\n')
			record.write(cc+'\n')
		
			f = file('transformation_input', 'w')
			cc='2, '+str(DCFparams.mtol)+', \''+object+'orien0\', \''+ssfile+'.bt\', \'varout\', \''+object+'_spheres\'\n'
			f.write(cc)
			f.close()
			record.write('writing transformation_input\n')
			record.write(cc)
			record.write('Getting transformation\n')
		
		
			print("Getting transformation")
			os.system("./transformation ")
			
	
			record.write('Did something move?\n')
			f = file('checktrans', 'r')
			a=f.readline()
			f.close()
			b=a.split(' ')[1]
			cc=b+'\n'
			record.write(cc)
			b2=a.split(' ')[-1].strip()
			cc=b2+' spheres\n'
			record.write(cc)
			nrot=int(b2)
	nsphmov=int(b2)
	if (nsphmov > hs):
		cc='Still MORE THAN THE ALLOWED NUMBER OF SPHERES MOVED with a reduced kick\n'	
		print(cc)
		record.write(cc)
		
		#**********************************
	
	#********** OBJECT N IN ORIENTATION N
	
	prevobject=object
	objnum=objnum+1
	object='object'+str(objnum)
	cc=object+' is '+ssfile+'\n'
	record.write(cc)
	record.close()
	record = file(DCFparams.recordfile, 'a')
	cc='cp '+ssfile+' '+object+'.ss'
	os.system(cc)
	##*************CHECK FOR ISOLATED SPHERES
	record.write('Checking for isolated spheres\n')
	print("Checking for isolated spheres")
	cc='./ssn -R '+str(DCFparams.septol)+' '+object+'.ss'
	record.write(cc+'\n')
	os.system(cc)
	ff=object+'.nbr'
	fiso = open(ff, "r")
	countiso=0
	for line in fiso:
		biso=line.split(' ') 
		ciso=len(biso)
		if (ciso <= 3):
			countiso=countiso+1
	cc='isolated spheres '+str(countiso-1)+'\n'
	print(cc)
	record.write(cc)
	fiso.close()
	nisosph=countiso-1	
	
	if (nisosph == 0): 
		cc='cp '+ssfile+'.bt '+object+'.bt'
		os.system(cc)
		
		
		#Create file rpx_chek to obtain object info with rpx
		f = file('rpx_check', 'w')
		f.write('\n')
		f.write('\n')
		arg=object+'.ss\n'
		f.write(arg)
		f.write('0\n')
		f.write('\n')
		f.write('\n')
		f.write('\n')
		f.write('y\n')
		f.write('\n')
		f.close()
		
		## Obtain object angular momemtum and period with rpx
		rpxnum=rpxnum+1
		rpxfile='rpxout'+str(rpxnum)
		cc=DCFparams.ccr+' < rpx_check > '+rpxfile
		os.system(cc)
		line = linecache.getline(rpxfile, 12)
		am0=line.split(' ')[8]
		line = linecache.getline(rpxfile, 11)
		p1=float(line.split(' ')[8])
		###define initial spin 
		w0=2.0*3.14159265/(float(p1)*3600.0)
		mi=float(am0)/w0	
		record.write('angular momemtum= '+str(am0)+'\n')
		record.write('period= '+str(p1)+'\n')
		record.write('spin= '+str(w0)+'\n')
		record.write('Moment of inertia= '+str(mi)+'\n')
		amrecord = file(DCFparams.amspinfile, 'a')
		amrecord.write(object+' '+str(am0)+' '+str(w0)+'\n')
		amrecord.close()

		record.close()
		record = file(DCFparams.recordfile, 'a')
		
		
		#********** TRANSFORM OBJECT N TO OBJECT N-1 IN ORIENTATION 0
		f = file('transformation_input', 'w')
		cc='2, '+str(DCFparams.mtol)+', \''+prevobject+'orien0\', \''+object+'.bt\', \'varout\', \''+object+'_spheres\'\n'
		f.write(cc)
		f.close()
		
		record.write('writing transformation_input\n')
		record.write(cc+'\n')
		record.write('Getting transformation\n')
		
		print("Getting transformation")
		os.system("./transformation ")
		print(" Done ")
		print("  ")
		f = file('varout', 'r')
		b=f.readline()
		cc='variables needed to transform '+object+' to orientation 0:\n'
		record.write(cc)
		record.write(b)
		
		#********** GET CM, PA AND TILE
		f = file('tiling_input', 'w')
		cc1='2, \'original.bt\', \''+object+'.bt\', '
		cc2='\'varout\', \''+object+'orien0\', \''+object+'_0\'\n'
		cc=cc1+cc2
		f.write(cc)
		f.close()
		record.write('writing tiling_input\n')
		record.write(cc)
		
		cc='Tiling '+object+'\n'
		record.write(cc)
		os.system("./tiling ")
		print(" Done ")
		print("  ")
		
		#********** GET HORIZON MAP, VISIBLE PAIRS AND TORQUES
		record.write('writing horizon_visiblepairs_input\n')
		f = file('horizon_visiblepairs_input', 'w')
		f.write('2\n')
		cc=object+'_0\n'
		f.write(cc)
		f.write('5\n')
		f.write('6\n')
		f.write('3\n')
		cc=object+'\n'
		f.write(cc)
		f.write('86\n')
		f.close()
		record.close()
		record = file(DCFparams.recordfile, 'a')
		record.write('Getting horizon_map and visible pairs\n')
		print("Getting Horizon Map and Visible Pairs")
		cc=DCFparams.cct+' < horizon_visiblepairs_input'
		os.system(cc)
		print(" Done ")
		print("  ")
		cc='Asteroid structure= '+object+'\n'
		record.write(cc)
		
		record.write('writing torquesobj_input\n')
		os.system('cp torques_input temp')
		f1 = open('temp', 'r')
		f2 = open('torquesobj_input', 'w')
		for line in f1:
		    f2.write(line.replace('original', object))
		f1.close()
		f2.close()
		record.write('Getting YORP torques\n')
		print("Getting YORP torques")
		cc=DCFparams.cct+' < torquesobj_input' 
		os.system(cc)
		print(" Done ")
		
		fi=object+'_torques'
		fi2=object+'torques'
		f = file(fi, 'r')
		f2 = file(fi2, 'w')
		for line in f.readlines():
			y = [value for value in line.split()]
			cc=y[1]+'	'+y[2]+'\n'
			f2.write(cc)
		f.close()
		for line in reversed(open(fi).readlines()[:-1]):
			y = [value for value in line.split()]
			cc1=-(float(y[1]))
			cc=str(cc1)+'	'+y[2]+'\n'
			f2.write(cc)
		f.close()
		f2.close()
		cc='Torques file= '+object+'torques\n'
		record.write(cc)
		mirecord = file(DCFparams.mifile, 'a')
		mirecord.write(object+'torques '+str(mi)+'\n')
		mirecord.close()
	


if (ntime == 5000):
	cc='DONE -> The simulation has finished.'	
	print(cc)
	record.write(cc)
elif (ntime == 8000):
	cc='STOPPED -> Time not evolving. Check Yorp_Evolution'	
	print(cc)
	record.write(cc)
else:
	cc='STOPPED -> There are '+str(nisosph)+' isolated spheres'	
	print(cc)
	record.write(cc)
record.close() 

