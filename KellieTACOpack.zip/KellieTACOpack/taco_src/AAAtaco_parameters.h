!!!!
!!!! Copy to the directory from which the 'make' command will be executed,
!!!! edit as needed, and rename to taco_parameters.h
!!!!


!----------------- USER-ADJUSTABLE COMPILE-TIME PARAMETERS ---------------------

! Number of tile rows between the ab plane ("equator") and pole
integer, parameter :: nlevels = 30

! Number of azimuth points for the horizon map
integer, parameter :: nhorizon = 50 

! Number of points to use in angular samples around a rotation or an orbit
integer, parameter :: n_rotation = 90 



!----------------- DON'T CHANGE ANYTHING BELOW THIS LINE! ----------------------

!-- DERIVED PARAMETERS

! Number of vertices
integer, parameter :: nvertices = 4*nlevels**2-6

! Number of tiles
integer, parameter :: ntiles = 8*(nlevels**2-2)

! Number of connected vertex pairs
integer, parameter :: npairs = ntiles*3/2

!-- PHYSICAL CONSTANTS

! Solar constant, W/m^2
real*8, parameter :: solarconstant = 1365.d0

! Speed of light, m/s
real*8, parameter :: speedoflight = 299792458.d0

! pi
real*8, parameter :: pi=3.14159265358979d0

! Stefan-Boltzmann constant, SI units
real*8, parameter :: stefanboltzmann = 5.6704d-8
