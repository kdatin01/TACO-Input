#!/bin/bash

#export OMP_NUM_THREADS=8

python DCFscript_continue.py >& output &
